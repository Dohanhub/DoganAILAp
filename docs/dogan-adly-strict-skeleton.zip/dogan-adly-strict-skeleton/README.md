# Dogan Compliance — Adly Strict™ Skeleton

Start here. See `docs/blueprint.md`.