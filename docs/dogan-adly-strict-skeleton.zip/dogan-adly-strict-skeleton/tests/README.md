# Tests

E2E and policy golden tests.