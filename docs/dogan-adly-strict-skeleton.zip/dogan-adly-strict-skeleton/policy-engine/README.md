# Policy Engine

Adly-DSL → IR → WASM. Include tests under `tests/`.